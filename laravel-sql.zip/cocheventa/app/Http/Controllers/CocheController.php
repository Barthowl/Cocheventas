<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Coche;
class CocheController extends Controller
{

// get
    function index(){ // select all
    return response()->json(Coche::all(),200);
        
    }
// post
    function store(Request $request){ // insert into
        try {
        $objeto = Coche::create($request->all());
        return response()->json(["id" => $objeto->id],200);
        } catch (\Exception $e) {
        return response()->json(["id"=>0],200);
        }
    }

// get
    function show($id){ // select one
        $coche = Coche::find($id);
        return response()->json(["coche" => $coche],200);
    }

// put
    function update(Request $request, $id){ // update
        try {
        $objeto = Coche::find($id);
        $resultado = $objeto->update($request->all());
        return response()->json(["resultado" => $resultado],200);
        } catch (\Exception $e) {
        return response()->json(["resultado"=>false],200);
        }

    }

// delete
    function destroy($id){ // delete
    try {
        $objeto = Coche::find($id);
        if($objeto != null){
        $resultado = $objeto->delete();
        return response()->json(["resultado" => $resultado],200);
        }
        } catch (\Exception $e){
        }
        return response()->json(["resultado" => false],200);
    }
}
