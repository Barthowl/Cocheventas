<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Documento</title>
    </head>
</html>
<body>
    
<table border="1">
    <tr>
        <td>Población</td>
        <td>47338080</td>
    </tr>
    <tr>
        <td>Superficie</td>
        <td>5050000</td>
    </tr>
    <tr>
        <td>PIB</td>
        <td>1770 billones</td>
    </tr>
    <tr>
        <td>Bandera</td>
        <td><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/135px-Flag_of_Spain.svg.png"></td>
    </tr>
</table>
</body><?php /**PATH /var/www/html/laravel/primeraApp/resources/views/elpais.blade.php ENDPATH**/ ?>