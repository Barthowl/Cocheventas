<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCocheTable extends Migration
{
 
    // create table
    public function up()
    {
        Schema::create('coche', function (Blueprint $table) {
            $table->id(); // autonumérico y clave principal
            $table->string('matricula', 12)->unique();
            $table->string('marca', 30);
            $table->string('modelo', 50);
            $table->string('color', 20);
            $table->string('foto', 120);
            $table->Integer('edad');
        });
    }

    
    // drop table
    public function down()
    {
        Schema::dropIfExists('coche');
    }
}
